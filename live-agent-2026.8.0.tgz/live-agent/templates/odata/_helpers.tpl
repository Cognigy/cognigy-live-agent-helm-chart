
{{/*
OData full name
*/}}
{{- define "live-agent-odata.fullname" -}}
{{ include "live-agent.fullname" . }}-odata
{{- end }}
