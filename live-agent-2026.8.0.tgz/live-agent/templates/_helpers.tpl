{{/*
Expand the name of the chart.
*/}}
{{- define "live-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "live-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "image.pullSecretsCognigy" -}}
  {{- $pullSecrets := list -}}

  {{- if and (.Values.imageCredentials.registry) (.Values.imageCredentials.username) (.Values.imageCredentials.password) -}}
      {{- $pullSecrets = append $pullSecrets "cognigy-registry-token" -}}
  {{- else if .Values.imageCredentials.pullSecrets -}}
    {{- range .Values.imageCredentials.pullSecrets -}}
      {{- $pullSecrets = append $pullSecrets . -}}
    {{- end -}}
  {{- else -}}
    {{ required "A valid value for .Values.imageCredentials is required!" .Values.imageCredentials.registry }}
    {{ required "A valid value for .Values.imageCredentials is required!" .Values.imageCredentials.username }}
    {{ required "A valid value for .Values.imageCredentials is required!" .Values.imageCredentials.password }}
    {{ required "A valid value for .Values.imageCredentials is required!" .Values.imageCredentials.pullSecrets }}
  {{- end -}}

  {{- if (not (empty $pullSecrets)) -}}
imagePullSecrets:
    {{- range $pullSecrets }}
  - name: {{ . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "live-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "live-agent.labels" -}}
helm.sh/chart: {{ include "live-agent.chart" . }}
{{ include "live-agent.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "live-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "live-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "live-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "live-agent.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Set Frontend URL
*/}}
{{- define "live-agent.frontend_url" -}}
{{- if .Values.frontendUrlOverride -}}
    "{{ .Values.urlProtocol }}://{{ .Values.frontendUrlOverride }}"
{{- else if .Values.ingress.hosts -}}
    {{- with (first .Values.ingress.hosts) }}
        "{{ $.Values.urlProtocol }}://{{ .host }}"
    {{- end }}
{{- else -}}
    "http://0.0.0.0:3000"
{{- end -}}
{{- end -}}

{{/*
Set postgres fullname
*/}}
{{- define "live-agent.postgresql.fullname" -}}
{{- if .Values.postgresql.fullnameOverride -}}
{{- .Values.postgresql.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.postgresql.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name "postgresql" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Set postgres host
*/}}
{{- define "live-agent.postgresql.host" -}}
{{- if .Values.postgresql.enabled -}}
  {{- if eq .Values.postgresql.architecture "replication" -}}
    {{- print .Release.Name "-postgresql-primary" -}}
  {{- else -}}
    {{- template "live-agent.postgresql.fullname" . -}}
  {{- end -}}
{{- else -}}
  {{- .Values.postgresql.host | quote -}}
{{- end -}}
{{- end -}}

{{/*
Set postgres replica host
*/}}
{{- define "live-agent.postgresql.replicaHost" -}}
{{- if and .Values.useReadReplica.enabled (eq .Values.postgresql.architecture "replication") -}}
  {{- print .Release.Name "-postgresql-read" -}}
{{- else -}}
  {{- template "live-agent.postgresql.host" . -}}
{{- end -}}
{{- end -}}



{{/*
Set postgres port
*/}}
{{- define "live-agent.postgresql.port" -}}
{{- if .Values.postgresql.enabled -}}
    "5432"
{{- else -}}
{{- default "5432" .Values.postgresql.port | quote -}}
{{- end -}}
{{- end -}}

{{/*
Set redis fullname
*/}}
{{- define "live-agent.redis.fullname" -}}
{{- if .Values.redis.fullnameOverride -}}
{{- .Values.redis.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.redis.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name "redis" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* redis sentinal host names based on the number of replicas set in the config */}}
{{- define "live-agent.redis.sentinel.hosts" -}}
{{- $replicaCount := int .Values.redis.replica.replicaCount -}}
{{- $hosts := "" -}}
{{- $port := (include "live-agent.redis.sentinel.port" $) -}}
{{- $headlessService := (include "live-agent.redis.headles.service.name" $) -}}
{{- $namespace := .Release.Namespace -}}
{{- if .Values.redis.enabled -}}
{{- range $i, $_ := until $replicaCount -}}
  {{- if $i }}{{- $hosts = printf "%s," $hosts -}}{{- end -}}
  {{- $hosts = printf "%s%s-node-%d.%s.%s.svc.cluster.local:%s" $hosts (include "live-agent.redis.host" $) $i $headlessService $namespace $port -}}
{{- end -}}
{{- $hosts | trimSuffix "," -}}
{{- end -}}
{{- end -}}

{{/* redis sentinel port */}}
{{- define "live-agent.redis.sentinel.port" -}}
{{- if .Values.redis.enabled -}}
    26379
{{- else -}}
{{- default 26379 .Values.redis.sentinel.port -}}
{{- end -}}
{{- end -}}

{{/* redis headless service name */}}
{{- define "live-agent.redis.headles.service.name" -}}
{{- if .Values.redis.enabled -}}
    {{- if .Values.redis.sentinel.enabled -}}
        {{- template "live-agent.redis.fullname" . -}}-headless
    {{- end -}}
{{- else -}}
{{- default "redis-headless" .Values.redis.headless.service.name -}}
{{- end -}}
{{- end -}}

{{/*
Set redis host
*/}}
{{- define "live-agent.redis.host" -}}
{{- if and (.Values.redis.enabled) (.Values.redis.sentinel.enabled) -}}
{{- template "live-agent.redis.fullname" . -}}
{{- else if .Values.redis.enabled -}}
{{- template "live-agent.redis.fullname" . -}}-master
{{- else -}}
{{- .Values.redis.host -}}
{{- end -}}
{{- end -}}

{{/*
Set redis port
*/}}
{{- define "live-agent.redis.port" -}}
{{- if .Values.redis.enabled -}}
    6379
{{- else -}}
{{- default 6379 .Values.redis.port -}}
{{- end -}}
{{- end -}}

{{/*
Set redis URL
*/}}
{{- define "live-agent.redis.url" -}}
{{- if .Values.redis.enabled -}}
    "redis://:{{ .Values.redis.auth.password }}@{{ template "live-agent.redis.host" . }}:{{ template "live-agent.redis.port" . }}"
{{- else if .Values.configmap.REDIS_TLS -}}
    "rediss://:{{ .Values.redis.password }}@{{ .Values.redis.host }}:{{ .Values.redis.port }}"
{{- else -}}
    "redis://:{{ .Values.redis.password }}@{{ .Values.redis.host }}:{{ .Values.redis.port }}"
{{- end -}}
{{- end -}}

{{/*
Set analytics fullname
*/}}
{{- define "live-agent.cognigy-analytics.fullname" -}}
  {{- printf "%s" "analytics-api-key" }}
{{- end -}}

{{/*
Set cognigy-oauth fullname
*/}}
{{- define "live-agent.cognigy-live-agent-cognigy-oauth.fullname" -}}
{{- printf "%s-%s" .Release.Name "cognigy-oauth" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Set smtp fullname
*/}}
{{- define "live-agent.smtp.fullname" -}}
{{- printf "%s-%s" .Release.Name "smtp" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Set cognigy-platform-app-token fullname
*/}}
{{- define "live-agent.cognigy-platform-app-token.fullname" -}}
{{- printf "%s-%s" .Release.Name "cognigy-platform-app-token" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Set cookies-integrity fullname
*/}}
{{- define "live-agent.cookies-integrity.fullname" -}}
{{- printf "%s-%s" .Release.Name "cookies-integrity" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Set postgres secret
*/}}
{{- define "live-agent.postgresql.secret" -}}
{{- if .Values.postgresql.auth.existingSecret -}}
  {{- .Values.postgresql.auth.existingSecret | quote -}}
{{- else -}}
  {{- template "live-agent.postgresql.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set postgres secretKey
*/}}
{{- define "live-agent.postgresql.secretKey" -}}
{{- if .Values.postgresql.auth.existingSecret -}}
  {{- .Values.postgresql.auth.secretKeys.adminPasswordKey | quote -}}
{{- else -}}
  "postgres-password"
{{- end -}}
{{- end -}}

{{/*
Set redis secret
*/}}
{{- define "live-agent.redis.secret" -}}
{{- if .Values.redis.auth.existingSecret -}}
  {{- .Values.redis.auth.existingSecret | quote -}}
{{- else -}}
  {{- template "live-agent.redis.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set redis secretKey
*/}}
{{- define "live-agent.redis.secretKey" -}}
{{- if .Values.redis.auth.existingSecretPasswordKey -}}
  {{- .Values.redis.auth.existingSecretPasswordKey | quote -}}
{{- else -}}
  "redis-password"
{{- end -}}
{{- end -}}

{{/*
Set SMTP secret
*/}}
{{- define "live-agent.smtp.secret" -}}
{{- if .Values.smtp.secret -}}
  {{- .Values.smtp.secret | quote -}}
{{- else -}}
  {{- template "live-agent.smtp.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set SMTP secretKey
*/}}
{{- define "live-agent.smtp.secretKey" -}}
{{- if .Values.smtp.secretPasswordKey -}}
  {{- .Values.smtp.secretPasswordKey | quote -}}
{{- else -}}
  "smtp-password"
{{- end -}}
{{- end -}}

{{/*
Set cognigy-platform-app-token secret
*/}}
{{- define "live-agent.cognigy-platform-app-token.secret" -}}
{{- if .Values.cognigyPlatformAppToken.existingSecret -}}
  {{- .Values.cognigyPlatformAppToken.existingSecret | quote -}}
{{- else -}}
  {{- template "live-agent.cognigy-platform-app-token.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set cognigy-platform-app-token secretKey
*/}}
{{- define "live-agent.cognigy-platform-app-token.secretKey" -}}
{{- if .Values.cognigyPlatformAppToken.existingSecretPasswordKey -}}
  {{- .Values.cognigyPlatformAppToken.existingSecretKey | quote -}}
{{- else -}}
  "cognigy-platform-app-token"
{{- end -}}
{{- end -}}

{{/*
Set analytics-api-key secret
*/}}
{{- define "live-agent.cognigy-analytics.secret" -}}
{{- if .Values.cognigyAnalytics.existingSecret -}}
  {{- .Values.cognigyAnalytics.existingSecret | quote -}}
{{- else -}}
  {{- template "live-agent.cognigy-analytics.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set cognigy-live-agent-cognigy-oauth secret
*/}}
{{- define "live-agent.cognigy-live-agent-cognigy-oauth.secret" -}}
{{- if .Values.cognigyOAuth.existingSecret -}}
  {{- .Values.cognigyOAuth.existingSecret | quote -}}
{{- else -}}
  {{- template "live-agent.cognigy-live-agent-cognigy-oauth.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set cognigy-live-agent-cognigy-oauth secretKey
*/}}
{{- define "live-agent.cognigy-live-agent-cognigy-oauth.secretKey" -}}
{{- if .Values.cognigyOAuth.existingSecretKey -}}
  {{- .Values.cognigyOAuth.existingSecretKey | quote -}}
{{- else -}}
  "cognigy-oauth-secret"
{{- end -}}
{{- end -}}

{{/*
Set cookies-integrity secret
*/}}
{{- define "live-agent.cookies-integrity.secret" -}}
{{- if .Values.cookiesIntegrity.existingSecret -}}
  {{- .Values.cookiesIntegrity.existingSecret | quote -}}
{{- else -}}
  {{- template "live-agent.cookies-integrity.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
Set cookies-integrity secretKey
*/}}
{{- define "live-agent.cookies-integrity.secretKey" -}}
{{- if .Values.cookiesIntegrity.existingSecret -}}
  {{- .Values.cookiesIntegrity.existingSecretKey | quote -}}
{{- else -}}
  "cookies-integrity-key"
{{- end -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for ingress.
*/}}
{{- define "grafana.ingress.apiVersion" -}}
  {{- if and (.Capabilities.APIVersions.Has "networking.k8s.io/v1") (semverCompare ">= 1.19-0" .Capabilities.KubeVersion.Version) -}}
      {{- print "networking.k8s.io/v1" -}}
  {{- else if .Capabilities.APIVersions.Has "networking.k8s.io/v1beta1" -}}
    {{- print "networking.k8s.io/v1beta1" -}}
  {{- else -}}
    {{- print "extensions/v1beta1" -}}
  {{- end -}}
{{- end -}}

{{/*
Return if ingress is stable.
*/}}
{{- define "grafana.ingress.isStable" -}}
  {{- eq (include "grafana.ingress.apiVersion" .) "networking.k8s.io/v1" -}}
{{- end -}}

{{/*
Return if ingress supports pathType.
*/}}
{{- define "grafana.ingress.supportsPathType" -}}
  {{- or (eq (include "grafana.ingress.isStable" .) "true") (and (eq (include "grafana.ingress.apiVersion" .) "networking.k8s.io/v1beta1") (semverCompare ">= 1.18-0" .Capabilities.KubeVersion.Version)) -}}
{{- end -}}

{{/*
Renders a value that contains template.
Usage:
{{ include "cognigyla.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $) }}
*/}}
{{- define "cognigyla.common.tplvalues.render" -}}
    {{- if typeIs "string" .value }}
        {{- tpl .value .context }}
    {{- else }}
        {{- tpl (.value | toYaml) .context }}
    {{- end }}
{{- end -}}

{{/*
Return the number of bytes given a value
following a base 2 or base 10 number system.
Input can be: b | B | k | K | m | M | g | G | Ki | Mi | Gi
Or number without suffix
Usage:
{{ include "live-agent.toBytes" .Values.path.to.the.Value }}
*/}}
{{- define "live-agent.toBytes" -}}
    {{- $si := . -}}
    {{- if not (typeIs "string" . ) -}}
        {{- $si = int64 $si | toString -}}
    {{- end -}}
    {{- $bytes := 0 -}}
    {{- if or (hasSuffix "B" $si) (hasSuffix "b" $si) -}}
        {{- $bytes = $si | trimSuffix "B" | trimSuffix "b" | float64 | floor -}}
    {{- else if or (hasSuffix "K" $si) (hasSuffix "k" $si) -}}
        {{- $raw := $si | trimSuffix "K" | trimSuffix "k" | float64 -}}
        {{- $bytes = mulf $raw (mul 1000) | floor -}}
    {{- else if or (hasSuffix "M" $si) (hasSuffix "m" $si) -}}
        {{- $raw := $si | trimSuffix "M" | trimSuffix "m" | float64 -}}
        {{- $bytes = mulf $raw (mul 1000 1000) | floor -}}
    {{- else if or (hasSuffix "G" $si) (hasSuffix "g" $si) -}}
        {{- $raw := $si | trimSuffix "G" | trimSuffix "g" | float64 -}}
        {{- $bytes = mulf $raw (mul 1000 1000 1000) | floor -}}
    {{- else if hasSuffix "Ki" $si -}}
        {{- $raw := $si | trimSuffix "Ki" | float64 -}}
        {{- $bytes = mulf $raw (mul 1024) | floor -}}
    {{- else if hasSuffix "Mi" $si -}}
        {{- $raw := $si | trimSuffix "Mi" | float64 -}}
        {{- $bytes = mulf $raw (mul 1024 1024) | floor -}}
    {{- else if hasSuffix "Gi" $si -}}
        {{- $raw := $si | trimSuffix "Gi" | float64 -}}
        {{- $bytes = mulf $raw (mul 1024 1024 1024) | floor -}}
    {{- else if (mustRegexMatch "^[0-9]+$" $si) -}}
        {{- $bytes = $si -}}
    {{- else -}}
        {{- printf "\n%s is invalid SI quantity\nSuffixes can be: b | B | k | K | m | M | g | G | Ki | Mi | Gi or without any Suffixes" $si | fail -}}
    {{- end -}}
    {{- $bytes | int64 -}}
{{- end -}}
