# Installing the Helm Chart

It is recommended to follow the [Cognigy Live Agent installation guide](https://docs.cognigy.com/live-agent/installation/deployment/installation-using-helm/)
# Creating a `custom-values.yaml` file

Before installing the Helm chart, please create a separate file called `custom-values.yaml`, it will be used to override the values in the `values.yaml` file. Several examples are provided in the documentation guide. 

It will help keep the installation custom values in one place. In every upgrade new values added to `values.yaml` will be described in the release notes and can be added to the `custom-values.yaml` file.
 
# Main values

The following values are very likely to change for each setup.

## Replicas

Define the replicas for the Live Agent app and worker pod. The recommendation is to have at least two worker pods for keeping consistency.

```yaml
app:
  replica: 1
worker:
  replica: 1
```

## OData service

OData service has its own configuration and can be disabled by setting the value `odata.enabled` to `'false'`.

## Using external PostgreSQL/Redis

In case there is a need for using an external PostgreSQL or Redis instances, follow these instructions.

### PostgreSQL

1. Go to the `values.yaml` file and scroll down to `postgresql` field. Change the `enabled` value to `false`.

2. Type the username credentials and uncomment the properties `postgresqlHost`, `postgresqlPort` giving them the right value.

3. A secret is created by default. Edit the password inside the Redis secret, the secret name is composed by the `release name` + `redis`. You can also use the `existingSecret` and `existingPasswordKey` properties using an existing secret on your cluster.

### Redis

1. Go to the `values.yaml` file and scroll down to `redis` field. Change the `enabled` value to `false`.

2. Type the username credentials and uncomment the properties `host`, `port` giving them the right value.

3. A secret is created by default. Edit the password inside the Redis secret, the secret name is composed by the `release name` + `redis`. You can also use the `existingSecret` and `existingPasswordKey` properties using an existing secret on your cluster.

## Specify the SMTP password in case you need login authentication

Uncomment the `smtp.secret` and `smtp.secretPasswordKey` values and set them to you secret containing the SMTP password.

## Ingress values

Each service has an ingress file, add your domain under the ingress sections in the `values.yaml` of each one like in the example below:

```
ingress:
  enabled: true
  annotations:
    kubernetes.io/ingress.class: traefik
  hosts:
    - host: "my-domain.com"
      paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: cognigy-live-agent
              port:
                number: 3000
``` 
